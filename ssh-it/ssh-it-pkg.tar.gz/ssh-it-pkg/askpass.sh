#! /bin/sh

echo "$SSH_PASSWORD"
